import { publicRoutes } from "@routes/publicRoutes";
import { protectedRoutes } from "@routes/protectedRoutes";

/**
 * Finds an item in an array by matching a specific key-value pair.
 * 
 * @template T - The type of items in the array
 * @param {T[]} arr - The array to search through
 * @param {keyof T} key - The property key to match against
 * @param {T[keyof T]} value - The value to search for
 * @returns {T | undefined} The found item or undefined if not found
 * 
 * @example
 * const users = [{ id: 1, name: 'John' }, { id: 2, name: 'Jane' }];
 * const user = findByKey(users, 'id', 1); // Returns { id: 1, name: 'John' }
 */
export function findByKey<T>(arr: T[], key: keyof T, value: T[keyof T]): T | undefined {
    return arr.find(item => item[key] === value);
}

/**
 * Flattens a nested route structure into a single-level array.
 * Recursively processes children routes and combines them with parent routes.
 * 
 * @template T - The type of route objects
 * @param {T[]} routes - Array of route objects that may contain nested children
 * @returns {T[]} Flattened array of all routes including nested children
 * 
 * @example
 * const routes = [{ key: 'parent', children: [{ key: 'child' }] }];
 * const flat = flattenRoutes(routes); // Returns [{ key: 'parent', ... }, { key: 'child' }]
 */
export function flattenRoutes<T extends { children?: T[] }>(routes: T[]): T[] {
    const flattened: T[] = [];
    
    routes.forEach(route => {
        flattened.push(route);
        if (route.children && route.children.length > 0) {
            flattened.push(...flattenRoutes(route.children));
        }
    });
    
    return flattened;
}

/**
 * Retrieves a route path by its key from the combined public and protected routes.
 * Supports nested children routes and dynamic parameter replacement in route paths.
 * 
 * @param {string} value - The route key to look up (e.g., 'login', 'discoveries', 'discoveriesId')
 * @param {Record<string, string>} [params] - Optional parameters to replace in the route path
 * @returns {string} The resolved route path with leading slash, or '/' if route not found
 * 
 * @example
 * // Simple route lookup
 * getRouteByKey('login'); // Returns '/login'
 * 
 * @example
 * // Route with parameters
 * getRouteByKey('discoveriesId', { id: '123' }); // Returns '/discovery/123'
 * 
 * @example
 * // Route with multiple parameters
 * getRouteByKey('discoveriesIdTab', { id: '123', tab: 'details' }); // Returns '/discovery/123/details'
 * 
 * @example
 * // Remove optional parameters
 * getRouteByKey('user-profile', {}); // Returns '/user' (removes /:id)
 */
export function getRouteByKey(value: string, params?: Record<string, string>): string {
    // Flatten all routes including nested children
    const allRoutes = [...flattenRoutes(publicRoutes as any[]), ...flattenRoutes(protectedRoutes as any[])] as any[];
    const item = findByKey(allRoutes, "key", value);

    if (!item?.path) return '/';

    let path = item.path as string;

    if (params && Object.keys(params).length > 0) {
        Object.entries(params).forEach(([key, val]) => {
            path = path.replace(`:${key}`, val);
        });
    } else if (params && Object.keys(params).length === 0) {
        path = path.replace(/\/:[^/]+/g, '');
    }

    return path.startsWith("/") ? path : `/${path}`;
}

export function ucFirstLetter(str:string) {
    return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

export const cleanErrorMessage = (message: string): string => {
    if (!message) return '';
    return message.replace(/^"([^"]+)"/, (_: string, field: string) => ucFirstLetter(field));
};

export function isTruthyOrOne(value: any): boolean {
    return value === true || value == 1;
}

export function isFalsyOrZero(value: any): boolean {
    return value === false || value == 0;
}