# CSS Variables Documentation

This document provides comprehensive documentation for all CSS custom properties (variables) used in the HumanisticsAI Frontend application.

## Table of Contents
- [Primary Colors](#primary-colors)
- [Status Colors](#status-colors)
- [Text Colors](#text-colors)
- [Background Colors](#background-colors)
- [Border Colors](#border-colors)
- [Interactive Colors](#interactive-colors)
- [Step Indicator Colors](#step-indicator-colors)
- [Shadows](#shadows)
- [Usage Guidelines](#usage-guidelines)

---

## Primary Colors

Brand colors used throughout the application.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--primary-orange` | `#d4a574` | Main brand color | Primary buttons, active states, focus indicators |
| `--primary-orange-light` | `rgba(212, 165, 116, 0.2)` | Light variant with 20% opacity | Hover backgrounds, subtle highlights |
| `--primary-orange-dark` | `rgba(212, 165, 116, 0.3)` | Dark variant with 30% opacity | Disabled button backgrounds |
| `--primary-gold` | `#c9a05f` | Secondary brand color | Hover states, accents |

**Example:**
```css
.button-primary {
  background-color: var(--primary-orange);
  color: var(--text-black);
}

.button-primary:hover {
  background-color: var(--primary-gold);
}
```

---

## Status Colors

Colors for feedback and status indicators.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--error-red` | `#d32f2f` | Error state color | Error messages, validation errors, destructive actions |
| `--error-red-light` | `rgba(211, 47, 47, 0.2)` | Light error with 20% opacity | Error backgrounds, focus rings |
| `--success-green` | `#4caf50` | Success state color | Success messages, completed states, checkmarks |
| `--warning-yellow` | `#ff9800` | Warning state color | Warning messages, caution indicators |

**Example:**
```css
.input-error {
  border-color: var(--error-red);
}

.success-message {
  color: var(--success-green);
}
```

---

## Text Colors

Colors for text and typography.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--text-white` | `#ffffff` | Pure white text | Primary text on dark backgrounds |
| `--text-black` | `#000000` | Pure black text | Text on light backgrounds, button text |
| `--text-white-70` | `rgba(255, 255, 255, 0.7)` | White with 70% opacity | Secondary text, less emphasis |
| `--text-white-90` | `rgba(255, 255, 255, 0.9)` | White with 90% opacity | Near-primary text, subtle hierarchy |
| `--text-muted` | `rgba(255, 255, 255, 0.5)` | White with 50% opacity | Placeholder text, disabled text |
| `--text-secondary` | `rgba(255, 255, 255, 0.6)` | White with 60% opacity | Secondary text, labels, captions |

**Example:**
```css
.heading {
  color: var(--text-white);
}

.caption {
  color: var(--text-secondary);
}

input::placeholder {
  color: var(--text-muted);
}
```

---

## Background Colors

Background colors for the dark theme.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--bg-dark-primary` | `#1a1a1a` | Primary dark background | Main page backgrounds, panels |
| `--bg-dark-secondary` | `#0f0f0f` | Secondary dark background | Sidebar, darker sections |
| `--bg-sidebar` | `#0f0f0f` | Sidebar background | Navigation sidebar |
| `--bg-main` | `#1a1a1a` | Main content background | Content areas |
| `--bg-card` | `rgba(255, 255, 255, 0.03)` | Card background | Cards, panels with subtle elevation |
| `--bg-input` | `rgba(255, 255, 255, 0.05)` | Input field background | Text inputs, textareas, form fields |
| `--bg-overlay` | `rgba(255, 255, 255, 0.9)` | Overlay background | Modals, dialogs (light overlay) |
| `--bg-hover` | `rgba(255, 255, 255, 0.05)` | Hover state background | Interactive elements on hover |
| `--bg-active` | `rgba(255, 255, 255, 0.08)` | Active state background | Pressed/active interactive elements |

**Additional Background Colors** (used in specific components):
| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--bg-dark` | `#1a1a1c` | Dark variant | Discovery content boxes |
| `--bg-dark-second` | `#212123` | Second dark variant | Discovery containers |
| `--bg-dark-third` | `#262626` | Third dark variant | Discovery option cards |

**Example:**
```css
.card {
  background-color: var(--bg-card);
}

.button:hover {
  background-color: var(--bg-hover);
}

.input-field {
  background-color: var(--bg-input);
}
```

---

## Border Colors

Colors for borders and dividers.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--border-default` | `rgba(255, 255, 255, 0.05)` | Default border color | Input borders, dividers, card borders |
| `--border-subtle` | `rgba(255, 255, 255, 0.03)` | Subtle border | Very light dividers, minimal borders |
| `--border-hover` | `rgba(255, 255, 255, 0.1)` | Hover border color | Input borders on hover |
| `--border-focus` | `var(--primary-orange)` | Focus border color | Input borders on focus, keyboard navigation |

**Example:**
```css
.input {
  border: 1px solid var(--border-default);
}

.input:hover {
  border-color: var(--border-hover);
}

.input:focus {
  border-color: var(--border-focus);
}
```

---

## Interactive Colors

Colors for links and interactive elements.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--link-color` | `var(--primary-orange)` | Link color | Text links, clickable text |
| `--link-hover` | `var(--primary-gold)` | Link hover color | Links on hover |
| `--link-visited` | `#b88f5f` | Visited link color | Previously visited links |
| `--hover-overlay` | `rgba(255, 255, 255, 0.05)` | Hover overlay | Subtle hover effects |

**Example:**
```css
a {
  color: var(--link-color);
}

a:hover {
  color: var(--link-hover);
}

a:visited {
  color: var(--link-visited);
}
```

---

## Step Indicator Colors

Colors specific to step indicators and progress components.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--step-active` | `var(--primary-orange)` | Active step color | Current step in progress |
| `--step-completed` | `var(--primary-orange)` | Completed step color | Finished steps |
| `--step-inactive` | `rgba(255, 255, 255, 0.3)` | Inactive step color | Upcoming/incomplete steps |
| `--step-text-active` | `var(--text-white)` | Active step text | Text for active step |
| `--step-text-inactive` | `var(--text-secondary)` | Inactive step text | Text for inactive steps |

**Example:**
```css
.step.active {
  color: var(--step-active);
}

.step.completed {
  color: var(--step-completed);
}

.step.inactive {
  color: var(--step-inactive);
}
```

---

## Shadows

Shadow effects for depth and elevation.

| Variable | Value | Description | Usage |
|----------|-------|-------------|-------|
| `--shadow-default` | `0 4px 6px -1px rgba(0, 0, 0, 0.1)` | Default shadow | Cards, elevated elements |
| `--shadow-focus` | `0 0 0 2px var(--primary-orange-light)` | Focus ring shadow | Keyboard focus indicators |
| `--shadow-error` | `0 0 0 2px var(--error-red-light)` | Error focus ring | Error state focus indicators |

**Example:**
```css
.card {
  box-shadow: var(--shadow-default);
}

.input:focus {
  box-shadow: var(--shadow-focus);
}

.input.error:focus {
  box-shadow: var(--shadow-error);
}
```

---

## Usage Guidelines

### Best Practices

1. **Always use CSS variables** instead of hardcoded colors
   ```css
   /* ❌ Bad */
   color: #d4a574;
   
   /* ✅ Good */
   color: var(--primary-orange);
   ```

2. **Use semantic variable names** based on purpose, not appearance
   ```css
   /* ❌ Bad */
   background-color: var(--primary-orange);  /* for error state */
   
   /* ✅ Good */
   background-color: var(--error-red);
   ```

3. **Maintain consistency** across components
   - Use `--text-secondary` for all secondary text
   - Use `--bg-hover` for all hover states
   - Use `--border-focus` for all focus states

4. **Layer opacity correctly**
   - Use lighter variants (`-light`) for backgrounds
   - Use full opacity for text and borders
   - Stack transparent colors for depth

### Accessibility Considerations

- Ensure sufficient contrast ratios (WCAG AA: 4.5:1 for normal text)
- Use focus indicators (`--border-focus`, `--shadow-focus`) for keyboard navigation
- Provide visual feedback for all interactive states (hover, active, disabled)

### Adding New Variables

When adding new CSS variables:

1. Add to `src/styles/variables.css`
2. Document in this file with:
   - Variable name
   - Value
   - Description
   - Usage examples
3. Use consistent naming conventions:
   - `--{category}-{variant}` (e.g., `--text-secondary`)
   - `--{category}-{color}-{variant}` (e.g., `--primary-orange-light`)

### Component-Specific Variables

Some components may define their own local CSS variables. These should:
- Be scoped to the component
- Reference global variables when possible
- Be documented in the component file

---

## Migration Guide

If you find hardcoded colors in the codebase:

1. Identify the color's purpose
2. Find or create an appropriate CSS variable
3. Replace the hardcoded value
4. Test in all relevant states (normal, hover, active, disabled)

**Example Migration:**
```css
/* Before */
.button {
  background-color: #d4a574;
  color: #000000;
}

.button:hover {
  background-color: #c9a05f;
}

/* After */
.button {
  background-color: var(--primary-orange);
  color: var(--text-black);
}

.button:hover {
  background-color: var(--primary-gold);
}
```

---

## File Location

All CSS variables are defined in:
```
src/styles/variables.css
```

This file is imported globally and available throughout the application.

---

## Related Documentation

- [Component Styling Guide](./STYLING_GUIDE.md) *(if exists)*
- [Theme System](./THEME_SYSTEM.md) *(if exists)*
- [Design System](./DESIGN_SYSTEM.md) *(if exists)*

---

**Last Updated:** November 4, 2025  
**Maintained By:** Development Team
