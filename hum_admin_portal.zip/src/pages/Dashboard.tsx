import React from 'react'
import { Box, Card, CardContent, Typography, Chip, Stack } from '@mui/material'
import Grid from '@mui/material/Grid2'
import { ArrowUpward, ArrowDownward } from '@mui/icons-material'

export default function Dashboard() {
  const [items, setItems] = React.useState<Array<{ id: string, title: string, metric: string, trend: string }>>([])
  const isUp = (t: string) => t.trim().startsWith('+')
  return (
    <Box sx={{ p: 3, bgcolor: 'var(--bg-main)', minHeight: '100vh' }}>
      <Typography variant="h5" sx={{ mb: 3, color: 'var(--text-white)', fontWeight: 600 }}>
        Dashboard
      </Typography>
      <Grid container spacing={2}>
        {items.map(i => {
          const up = isUp(i.trend)
          return (
            <Grid key={i.id} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
              <Card
                variant="outlined"
                sx={{
                  bgcolor: 'var(--bg-card-panel)',
                  borderColor: 'var(--border-default)',
                  borderRadius: '12px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                  '&:hover': {
                    borderColor: 'var(--border-hover)',
                  }
                }}
              >
                <CardContent>
                  <Typography variant="overline" sx={{ color: 'var(--text-secondary)' }}>
                    {i.title}
                  </Typography>
                  <Typography variant="h4" sx={{ mt: 1, color: 'var(--text-white)' }}>
                    {i.metric}
                  </Typography>
                  <Stack direction="row" alignItems="center" spacing={1} sx={{ mt: 1 }}>
                    <Chip
                      size="small"
                      color={up ? 'success' : 'error'}
                      icon={up ? <ArrowUpward /> : <ArrowDownward />}
                      label={i.trend}
                      variant="outlined"
                    />
                    <Typography variant="caption" sx={{ color: 'var(--text-secondary)' }}>
                      WoW
                    </Typography>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          )
        })}
      </Grid>
    </Box>
  )
}
