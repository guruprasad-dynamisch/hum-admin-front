import React, { forwardRef, useState } from 'react';
import { TextField, TextFieldProps, IconButton, InputAdornment } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useController } from 'react-hook-form';
import "@styles/fields/InputField.css";

interface InputFieldProps extends Omit<TextFieldProps, 'name' | 'value' | 'onChange' | 'onBlur' | 'error'> {
  /** Field name (required for react-hook-form mode) */
  name?: string;
  /** Input type */
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url' | 'search';
  /** Mode of operation */
  mode?: 'standalone' | 'react-hook-form';
  /** React Hook Form control */
  control?: any;
  /** React Hook Form validation rules */
  rules?: any;
  /** Standalone mode value */
  value?: string | number;
  /** Standalone mode onChange handler */
  onChange?: (value: string | number) => void;
  /** Standalone mode onBlur handler */
  onBlur?: () => void;
  /** Whether field is required */
  required?: boolean;
  /** Custom className for the wrapper */
  className?: string;
  /** Show label (default: true) */
  showLabel?: boolean;
  /** Show password visibility toggle (only for password type, default: true) */
  showPasswordToggle?: boolean;
}

const InputField = forwardRef<HTMLInputElement, InputFieldProps>(
  (
    {
      mode = 'standalone',
      name = '',
      label,
      type = 'text',
      placeholder,
      disabled = false,
      required = false,
      className = '',
      showLabel = true,
      showPasswordToggle = true,
      control,
      rules,
      value,
      onChange,
      onBlur,
      sx,
      ...props
    },
    ref
  ) => {
    // State for password visibility
    const [showPassword, setShowPassword] = useState(false);

    // Handle react-hook-form mode
    const isReactHookForm = mode === 'react-hook-form' && control && name;
    let fieldProps: any = {};
    let error = null;

    if (isReactHookForm) {
      const {
        field: { onChange: fieldOnChange, onBlur: fieldOnBlur, value: fieldValue, ref: fieldRef },
        fieldState: { error: fieldError },
      } = useController({
        name,
        control,
        rules,
        defaultValue: value || '',
      });

      fieldProps = {
        ref: fieldRef,
        value: fieldValue || '',
        onChange: fieldOnChange,
        onBlur: fieldOnBlur,
      };
      error = fieldError;
    }

    // Default styling
    const defaultSx = {
      width: '100%',
      '& .MuiInputBase-root': {
        backgroundColor: 'var(--bg-input)',
        borderRadius: '8px',
      },
      '& .MuiInputBase-input': {
        padding: "12px 14px",
        color: 'var(--text-white)',
        backgroundColor: 'transparent',
        borderRadius: '8px',
        '&:-webkit-autofill': {
          WebkitBoxShadow: '0 0 0 1000px var(--bg-input) inset',
          WebkitTextFillColor: 'var(--text-white)',
          borderRadius: '8px',
        },
        '&:-webkit-autofill:hover': {
          WebkitBoxShadow: '0 0 0 1000px var(--bg-input) inset',
          WebkitTextFillColor: 'var(--text-white)',
        },
        '&:-webkit-autofill:focus': {
          WebkitBoxShadow: '0 0 0 1000px var(--bg-input) inset',
          WebkitTextFillColor: 'var(--text-white)',
        },
        '&:autofill': {
          backgroundColor: 'var(--bg-input)',
          color: 'var(--text-white)',
        },
      },
      '& .MuiInputBase-input:focus': {
        outline: 'none',
      },
      '& .MuiOutlinedInput-root': {
        '& fieldset': {
          borderColor: error ? 'var(--error-red)' : 'var(--border-default)',
          borderRadius: '8px',
        },
        '&:hover fieldset': {
          borderColor: error ? 'var(--error-red)' : 'var(--border-hover)',
        },
        '&.Mui-focused fieldset': {
          borderColor: error ? 'var(--error-red)' : 'var(--primary-orange)',
          borderWidth: '2px',
        },
      },
      ...sx,
    };

    // Determine the actual input type (handle password visibility)
    const actualType = type === 'password' && showPassword ? 'text' : type;

    // Password visibility toggle button
    const passwordToggleAdornment = type === 'password' && showPasswordToggle ? (
      <InputAdornment position="end">
        <IconButton
          aria-label="toggle password visibility"
          onClick={() => setShowPassword(!showPassword)}
          onMouseDown={(e) => e.preventDefault()}
          edge="end"
          sx={{
            color: 'var(--text-secondary)',
            '&:hover': {
              color: 'var(--text-white)',
              backgroundColor: 'transparent',
            },
          }}
        >
          {showPassword ? <VisibilityOff /> : <Visibility />}
        </IconButton>
      </InputAdornment>
    ) : undefined;

    const inputProps = {
      ...props,
      id: name,
      type: actualType,
      placeholder: placeholder,
      disabled: disabled,
      InputProps: {
        endAdornment: passwordToggleAdornment,
      },
      ...(isReactHookForm ? fieldProps : {
        ref: ref,
        value: value || '',
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
          const newValue = type === 'number' ? Number(e.target.value) : e.target.value;
          onChange?.(newValue);
        },
        onBlur: onBlur,
      }),
    };

    return (
      <div className={`input-field-wrapper ${className}`}>
        {showLabel && label && (
          <label htmlFor={name} className="input-field-label">
            {label}{required ? <span className='required'>*</span> : ""}
          </label>
        )}
        <TextField
          {...inputProps}
          label={undefined} // Remove the built-in label since we're using custom label
          error={!!error}
          helperText={''}
          variant="outlined"
          sx={defaultSx}
        />
        {error && (
          <span className="error-text">{error.message}</span>
        )}
      </div>
    );
  }
);

InputField.displayName = 'InputField';

export default InputField;
