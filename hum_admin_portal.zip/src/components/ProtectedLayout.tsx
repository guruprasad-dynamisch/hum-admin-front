import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import { Box } from '@mui/material'

export default function ProtectedLayout() {
  return (
    <Box
      sx={{
        display: 'flex',
        height: '100vh',
        overflow: 'hidden',
        bgcolor: 'var(--bg-main)',
        color: 'var(--text-white)',
      }}
    >
      {/* Fixed Sidebar */}
      <Box 
        sx={{ 
          height: '100vh', 
          display: 'flex', 
          flexDirection: 'column',
          position: 'sticky',
          top: 0,
          left: 0,
        }}
      >
        <Sidebar />
      </Box>

      {/* Scrollable Main Content Area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          height: '100vh',
          overflowY: 'auto',
          overflowX: 'hidden',
          bgcolor: 'var(--bg-main)',
        }}
      >
        <Outlet />
      </Box>
    </Box>
  )
}
