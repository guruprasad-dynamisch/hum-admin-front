import { IconButton, IconButtonProps } from "@mui/material";

interface IconBtnProps extends Omit<IconButtonProps, 'size'> {
  children: React.ReactNode;
  size?: 'small' | 'medium' | 'large';
  variant?: 'default' | 'primary' | 'secondary';
}

const IconBtn = ({
  children,
  size = 'small',
  variant = 'default',
  sx = {},
  ...props
}: IconBtnProps) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return {
          backgroundColor: 'var(--primary-orange)',
          color: 'var(--text-black)',
          '&:hover': {
            backgroundColor: 'var(--primary-gold)',
          },
          '&.Mui-disabled': {
            backgroundColor: 'var(--primary-orange-dark)',
            color: 'rgba(0, 0, 0, 0.3)',
          },
        };
      case 'secondary':
        return {
          color: 'var(--text-secondary)',
          '&:hover': {
            color: 'var(--text-white-70)',
            backgroundColor: 'var(--bg-hover)',
          },
        };
      case 'default':
      default:
        return {
          color: 'var(--text-secondary)',
          '&:hover': {
            color: 'var(--text-white-70)',
            backgroundColor: 'var(--bg-hover)',
          },
        };
    }
  };

  return (
    <IconButton
      size={size}
      sx={{
        ...getVariantStyles(),
        ...sx,
      }}
      {...props}
    >
      {children}
    </IconButton>
  );
};

export default IconBtn;
