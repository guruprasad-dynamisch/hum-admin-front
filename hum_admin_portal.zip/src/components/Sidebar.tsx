import { useMemo, useState } from 'react'
import { List, Box, IconButton } from '@mui/material'
import { useAppSelector } from '@redux/store'
import { selectUser } from '@redux/slices/authSlice'
import { Role } from '@constants/roles'
import { getAllNavigationForRole } from '@constants/navigation'
import SidebarSection from './sidebar/SidebarSection'
import SidebarItem from './sidebar/SidebarItem'
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft'

const DRAWER_WIDTH = 300
const COLLAPSED_WIDTH = 72

interface SidebarProps {
  open?: boolean
  onToggle?: (open: boolean) => void
}

export default function Sidebar({ open: controlledOpen, onToggle }: SidebarProps) {
  const [internalOpen, setInternalOpen] = useState(false)
  const user = useAppSelector(selectUser)

  // Use controlled or internal state
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen
  const handleToggle = () => {
    const newState = !isOpen
    if (onToggle) {
      onToggle(newState)
    } else {
      setInternalOpen(newState)
    }
  }

  // Get user role, default to USER if not set
  const userRole = (user?.userType as Role) || Role.USER

  // Get navigation items filtered by role
  const { top: topNavItems, bottom: bottomNavItems } = useMemo(() => {
    return getAllNavigationForRole(userRole)
  }, [userRole])

  const sidebarContent = (
    <Box
      component="nav"
      aria-label="sidebar navigation"
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        bgcolor: 'var(--bg-sidebar)',
        width: isOpen ? DRAWER_WIDTH : COLLAPSED_WIDTH,
        transition: 'width 0.3s ease-in-out',
        borderRight: '1px solid var(--border-default)',
      }}
    >
      {/* Logo and Toggle Button */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          p: 1.5,
          minHeight: 64,
          gap: 1,
        }}
      >
        {/* Logo */}
        <Box
          sx={{
            cursor: isOpen ? 'default' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            flex: 1,
            minWidth: 0,
            '&:hover': !isOpen ? {
              opacity: 0.8,
            } : {},
          }}
        >
          <Box
            component="img"
            src="/assets/hum_logo.png"
            alt="Humanistics Logo"
            sx={{
              width: 40,
              height: 40,
              objectFit: 'contain',
            }}
          />
        </Box>

        {/* Collapse Button - Only show when open */}
        {isOpen && (
          <IconButton
            onClick={handleToggle}
            size="small"
            sx={{
              color: 'var(--text-secondary)',
              flexShrink: 0,
              '&:hover': {
                bgcolor: 'var(--bg-hover)',
                color: 'var(--text-white)',
              },
            }}
          >
            <ChevronLeftIcon />
          </IconButton>
        )}
      </Box>

      {/* Top Navigation Items */}
      <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', px: isOpen ? 1.5 : 0.5, py: 1 }}>
        <SidebarSection>
          <List disablePadding>
            {topNavItems.map((item) => (
              <SidebarItem
                key={item.id}
                label={item.label}
                path={item.path}
                icon={item.icon}
                collapsed={!isOpen}
                popupComponent={item.popupComponent}
              />
            ))}
          </List>
        </SidebarSection>
      </Box>

      {/* Bottom Navigation Items */}
      <Box sx={{ px: isOpen ? 1.5 : 0.5, py: 1 }}>
        <SidebarSection>
          <List disablePadding>
            {bottomNavItems.map((item) => (
              <SidebarItem
                key={item.id}
                label={item.label}
                path={item.path}
                icon={item.icon}
                onClick={item.onClick}
                collapsed={!isOpen}
                popupComponent={item.popupComponent}
              />
            ))}
          </List>
        </SidebarSection>
      </Box>
    </Box>
  )

  return sidebarContent
}
