import { useMemo, useState, useEffect } from 'react'
import { useAppSelector } from '@redux/store'
import { selectUser } from '@redux/slices/authSlice'
import { Role } from '@constants/roles'
import { getAllNavigationForRole } from '@constants/navigation'
import SidebarSection from './sidebar/SidebarSection'
import SidebarItem from './sidebar/SidebarItem'
import { cn } from '@utils/classNames'
import '@styles/components/sidebar.scss'

interface SidebarProps {
  open?: boolean
  onToggle?: (open: boolean) => void
  mobileOpen?: boolean
}

export default function Sidebar({ open: controlledOpen, onToggle, mobileOpen = false }: SidebarProps) {
  const [internalOpen, setInternalOpen] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const user = useAppSelector(selectUser)

  // Use controlled or internal state
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen

  // Check if mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768)
    }

    checkMobile()
    window.addEventListener('resize', checkMobile)

    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Get user role, default to USER if not set
  const userRole = (user?.role as Role) || Role.USER

  // Get navigation items filtered by role
  const { top: topNavItems, bottom: bottomNavItems } = useMemo(() => {
    return getAllNavigationForRole(userRole)
  }, [userRole])

  // Handle nav item click on mobile - close sidebar
  const handleNavItemClick = () => {
    if (isMobile && onToggle) {
      onToggle(false)
    }
  }

  return (
    <nav className={cn('sidebar', {
      'expanded': isOpen,
      'collapsed': !isOpen,
      'mobile-open': mobileOpen
    })} aria-label="sidebar navigation">
      {/* Logo Section */}
      <div className="sidebar-logo-section">
        <div className="sidebar-logo-container">
          {isOpen && <img
            src="/assets/humanistics_logo_transparent.webp"
            alt="Humanistics AI"
            className="sidebar-logo-image"
          />}
        </div>
      </div>

      {/* Top Navigation Items */}
      <div className={cn('sidebar-nav-menu', {
        'expanded': isOpen,
        'collapsed': !isOpen
      })}>
        <SidebarSection collapsed={!isOpen}>
          {topNavItems.map((item) => (
            <SidebarItem
              key={item.id}
              label={item.label}
              path={item.path}
              icon={item.icon}
              collapsed={!isOpen}
              popupComponent={item.popupComponent}
              onNavClick={handleNavItemClick}
            />
          ))}
        </SidebarSection>
      </div>
    </nav>
  )
}
