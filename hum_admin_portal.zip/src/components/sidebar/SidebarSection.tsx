import React from 'react'
import { Box, Typography, Divider } from '@mui/material'

interface SidebarSectionProps {
  title?: string
  children: React.ReactNode
  showDivider?: boolean
}

export default function SidebarSection({ title, children, showDivider = false }: SidebarSectionProps) {
  return (
    <Box sx={{ mb: 2 }}>
      {title && (
        <Typography
          variant="overline"
          sx={{
            px: 2,
            py: 1,
            display: 'block',
            color: 'text.secondary',
            fontSize: '0.75rem',
            fontWeight: 600,
            letterSpacing: '0.5px',
          }}
        >
          {title}
        </Typography>
      )}
      {children}
      {showDivider && <Divider sx={{ my: 2, opacity: 0.1 }} />}
    </Box>
  )
}
