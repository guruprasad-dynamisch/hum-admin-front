import React from 'react'
import { NavLink } from 'react-router-dom'
import { ListItemButton, ListItemIcon, ListItemText, Tooltip } from '@mui/material'
import { usePopup } from '@hooks/use-popup'

interface SidebarItemProps {
  label: string
  path?: string
  icon: React.ReactNode
  onClick?: (event?: React.MouseEvent<HTMLElement>) => void
  collapsed?: boolean
  popupComponent?: React.ComponentType<any>
}

export default function SidebarItem({ label, path, icon, onClick, collapsed = false, popupComponent: PopupComponent }: SidebarItemProps) {
  const popup = usePopup()

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    if (PopupComponent) {
      event.preventDefault()
      popup.open(event)
    }
    onClick?.(event)
  }

  // Only use NavLink if there's a path AND no popup component
  const buttonProps = (path && !PopupComponent) ? { component: NavLink, to: path } : {}

  const button = (
    <ListItemButton
      {...buttonProps}
      onClick={handleClick}
      sx={{
        borderRadius: 1,
        mb: 0.5,
        px: collapsed ? 1.5 : 2,
        py: 2,
        justifyContent: collapsed ? 'center' : 'flex-start',
        transition: 'all 0.15s ease-in-out',
        color: 'var(--text-secondary)',
        '&:hover': {
          bgcolor: 'var(--bg-hover)',
          color: 'var(--text-white)',
        },
        '&.active': {
          bgcolor: 'var(--bg-active)',
          color: 'var(--text-white)',
          '& .MuiListItemIcon-root': {
            color: 'var(--primary-orange)',
          },
        },
      }}
    >
      <ListItemIcon 
        sx={{ 
          minWidth: collapsed ? 'auto' : 40, 
          color: 'inherit',
          justifyContent: 'center',
          '& svg': {
            fontSize: '1.35rem'
          }
        }}
      >
        {icon}
      </ListItemIcon>
      {!collapsed && (
        <ListItemText 
          primary={label}
          slotProps={{
            primary: {
              sx: {
                fontSize: '0.875rem',
                fontWeight: 500,
              }
            }
          }}
        />
      )}
    </ListItemButton>
  )

  // Wrap with tooltip when collapsed
  const content = collapsed ? (
    <Tooltip title={label} placement="right" arrow>
      {button}
    </Tooltip>
  ) : button

  return (
    <>
      {content}
      {PopupComponent && (
        <PopupComponent 
          open={popup.isOpen}
          onClose={popup.close}
          anchorEl={popup.anchorEl}
        />
      )}
    </>
  )
}
