import Profile from '@pages/Profile'
import Logout from '@pages/Logout'
import Dashboard from '@pages/Dashboard'
import { Role } from '@constants/roles'
import { ProtectedRouteConfig } from './types'

export const protectedRoutes: ProtectedRouteConfig[] = [
  {
    key: 'dashboard',
    path: 'dashboard',
    element: Dashboard,
    allowedRoles: [Role.USER, Role.ADMIN],
  },
  {
    key: 'profile',
    path: 'profile',
    element: Profile,
    allowedRoles: [Role.USER, Role.ADMIN],
  },
  {
    key: 'logout',
    path: 'logout',
    element: Logout,
    allowedRoles: [Role.USER, Role.ADMIN],
  },
]
